# please take some beginner tutorials before jumping onto colabs
# ignore mounitng drive onto colabs if not working on it.
